import { useState, useEffect } from "react";
import {  useLoadScript, } from "@react-google-maps/api";
import Map from "../Map/Map"

export default function Home() {
  const { isLoaded } = useLoadScript({
    googleMapsApiKey: ""
  });
  const [countries, setCountries] = useState([]);

  useEffect(() => {
    fetch('https://restcountries.com/v3.1/all')
      .then(response => response.json())
      .then(data => {
        const dataMap = data.map((val, i) => {
            return {
                id: i,
                name: val.name.common,
                latitude: val.capitalInfo?.latlng?.[0],
                longitude: val.capitalInfo?.latlng?.[1],
            }
        })
        setCountries(dataMap)
    });
      
  }, []);

  if (!isLoaded) return <div>Loading...</div>;

  return <Map countries={countries} />;
}

