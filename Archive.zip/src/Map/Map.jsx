

import { useState } from "react";
import { GoogleMap, Marker, InfoWindow } from "@react-google-maps/api";
import './Map.css';

const Map = ({countries}) => {
    const [tooltip, setTooltip] = useState();
    return (
      <GoogleMap zoom={3} center={{ lat: 44, lng: 80 }} mapContainerClassName="map-container">
      {tooltip && <InfoWindow position={{ lat: parseFloat(tooltip.latitude, 10), lng: parseFloat(tooltip.longitude, 10) }}>
          <div>{tooltip.name}</div>
      </InfoWindow>}
      {countries &&
        countries.map((place, i) => {
          let lat = parseFloat(place.latitude, 10);
          let lng = parseFloat(place.longitude, 10);
          return (
            <Marker
              id={place.id}
              key={place.id}
              position={{ lat: lat, lng: lng }}
              title="Click to zoom"
              onClick={() =>{ setTooltip(place)}}
            >
            </Marker>
          );
        })}
      </GoogleMap>
    );
  }

  export default Map